<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Article_category extends Model
{
    //
}
